package ru.ifmo.cs.bcomp.ui.components;

public enum BusNames {
    DR_ALU,
    CR_ALU,
    IP_ALU,
    SP_ALU,
    AC_ALU,
    BR_ALU,
    PS_ALU,
    IR_ALU,
    ALU_COMM,
    COMM_ALL,
    COMM_DR,
    COMM_CR,
    COMM_IP,
    COMM_SP,
    COMM_AC,
    COMM_AR,
    COMM_BR,
    COMM_PS,
    MEM_IO,
    MEM_W,
    MEM_R,
    CU


}
