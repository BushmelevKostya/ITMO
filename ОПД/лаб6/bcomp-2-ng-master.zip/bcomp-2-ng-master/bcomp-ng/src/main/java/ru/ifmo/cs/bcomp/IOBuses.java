/*
 * $Id$
 */
package ru.ifmo.cs.bcomp;

/**
 *
 * @author Dmitry Afanasiev <KOT@MATPOCKuH.Ru>
 */
public enum IOBuses {
	IOData,
	IOAddr,
	IOCtrl
}
