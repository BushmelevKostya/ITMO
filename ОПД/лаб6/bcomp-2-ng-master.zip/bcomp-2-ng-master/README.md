# bcomp (Basic Computer)
This is simple computer model studied in ITMO University since 1982 by first year students. 
Its features are simple instructions set (inspired from PDP-8 and PDP-11), simple microprogram model and logic scheme to easy learn basics of computer architecture.

All documentation is unfortunativelly in Russian. You can look at https://se.ifmo.ru/courses/csbasics for details.
There is also lectures track on https://www.youtube.com/playlist?list=PLBWafxh1dFuwbs2bc_ba_1FIm4SzFYg2p

There are two branches for old model v1 (this model was studied until year 2019) and next generation model v2 (current).
Folder "docs" is for old model and would be deleted in the future for v2. 
